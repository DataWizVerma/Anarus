const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const axios = require('axios');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

const CONCURRENCY = 15;           // number of parallel checks
const REQUEST_TIMEOUT = 18000;    // 18 seconds

async function checkLink(url) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);

  try {
    let response = await axios({
      method: 'HEAD',
      url,
      timeout: REQUEST_TIMEOUT,
      signal: controller.signal,
      validateStatus: null,
      maxRedirects: 5,
    });

    if (response.status === 405 || response.status === 501) {
      response = await axios({
        method: 'GET',
        url,
        timeout: REQUEST_TIMEOUT,
        signal: controller.signal,
        headers: { Range: 'bytes=0-0' },
        validateStatus: null,
        maxRedirects: 5,
      });
    }

    clearTimeout(timeoutId);
    const isWorking = response.status >= 200 && response.status < 400;
    return {
      url,
      isBroken: !isWorking,
      statusMessage: `${response.status} ${response.statusText || ''}`.trim(),
    };
  } catch (error) {
    clearTimeout(timeoutId);
    let errorMsg = 'Network error';
    if (error.code === 'ECONNABORTED' || error.name === 'AbortError') {
      errorMsg = 'Timeout (>18s)';
    } else if (error.response) {
      errorMsg = `HTTP ${error.response.status}`;
    } else if (error.request) {
      errorMsg = 'No response (server down)';
    } else {
      errorMsg = error.message;
    }
    return { url, isBroken: true, statusMessage: errorMsg };
  }
}

async function processLinks(socket, links) {
  const total = links.length;
  let checked = 0;
  let brokenCount = 0;
  let workingCount = 0;
  const brokenLinks = [];
  const startTime = Date.now();

  const queue = [...links];
  let activeWorkers = 0;
  let resolveAll = null;
  const allDone = new Promise(resolve => { resolveAll = resolve; });

  function updateProgress(currentLink) {
    const percent = (checked / total) * 100;
    const elapsed = Date.now() - startTime;
    const avgTime = elapsed / (checked || 1);
    const remaining = (total - checked) * avgTime;

    socket.emit('progress', {
      checked,
      total,
      brokenCount,
      workingCount,
      currentLink: currentLink || 'finalizing',
      percent,
      etaMs: remaining,
      avgTimeMs: avgTime,
    });
  }

  async function worker() {
    while (queue.length > 0) {
      const url = queue.shift();
      updateProgress(url);
      const result = await checkLink(url);
      checked++;
      if (result.isBroken) {
        brokenCount++;
        brokenLinks.push({ url: result.url, status: result.statusMessage });
        socket.emit('brokenLinkFound', { url: result.url, error: result.statusMessage });
      } else {
        workingCount++;
      }
      updateProgress(null);
    }
    activeWorkers--;
    if (activeWorkers === 0 && resolveAll) resolveAll();
  }

  activeWorkers = Math.min(CONCURRENCY, total);
  for (let i = 0; i < activeWorkers; i++) worker();
  await allDone;

  socket.emit('checkComplete', {
    totalLinks: total,
    brokenCount,
    workingCount,
    brokenLinks,
  });
}

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  let isScanning = false;

  socket.on('startCheck', async (data) => {
    if (isScanning) return;
    const links = data.links;
    if (!links || !links.length) {
      socket.emit('error', { message: 'No links provided' });
      return;
    }
    isScanning = true;
    try {
      await processLinks(socket, links);
    } catch (err) {
      socket.emit('error', { message: err.message });
    } finally {
      isScanning = false;
      socket.disconnect();
    }
  });

  socket.on('disconnect', () => console.log('Client disconnected:', socket.id));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});